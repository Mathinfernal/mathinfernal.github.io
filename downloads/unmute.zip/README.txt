Unmute :

Welcome to Unmute, a free music player without ads made by Mathinfernal ! Thank you for checking it out!



Technologies Used :

Python 3.11
Visual Studio Code



License :

Unmute is proprietary software. Copyright © 2025 Mathinfernal. All Rights Reserved.



Medias :

Have questions or suggestions ? Reach out to me at :

Discord : discord.gg/ngZAHcGKgh
Youtube : youtube.com/@Mathinfernal
Twitch : twitch.tv/mathinfernal